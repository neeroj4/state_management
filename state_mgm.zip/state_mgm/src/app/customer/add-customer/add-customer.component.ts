import { Component } from '@angular/core';
import { State, Store } from '@ngrx/store';
import { CustomerState } from '../store/reducer/customer.reducer';
import { Customer } from 'src/app/models/customer';
import { addCustomers } from '../store/action/customer.actions';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent {
  constructor(private store: Store<CustomerState>) {

  }

  addCustomer(customerName: string) {
     const customer = new Customer();
    customer.name = customerName;
    
    this.store.dispatch(addCustomers(customer));
  }

}
